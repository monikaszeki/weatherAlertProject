<?php

  require_once  $_SERVER['DOCUMENT_ROOT'].'/config/config.php'; 

  
	$alert  = new alertClass();
  //Get users alert from table who signed up for alerts
  $userAlerts = $alert->getAlerts();
  $userToSend = array();

  if($userAlerts){

  	$wh = new weatherClass();
  	foreach ($userAlerts as $key => $value) {
      //get weather data for a specific city
  	 	$wh->setCityId($value['city_id']);
		  $data = $wh->connectApi();
  		$send = false;	
  		//check the temperatures
  		if($value['temp_max'] < ceil($data->main->temp) or $value['temp_min'] > ceil($data->main->temp)){
  			$send = true; 
  		}
    	if($send){
    		$arrayToPush = array('user_alert_id' => $value['id'], 'user_id' => $value['user_id']);
    		array_push($userToSend,$arrayToPush); 
    	}
  	}
  	$wh->close($userToSend);
 		//Send mail 
 		if(count($userToSend) != 0) {
      $user = new usersClass();
 			foreach ($userToSend as $key => $value) {
 				$userData = $user->getUserById($value['user_id']);
 				//Only send just once in a day
        $isSend = $alert->checkIsSend($value['user_alert_id']);
   			if(!$isSend){ 
          $subject = "Weather alert";
          $message = "The temperature is reached your limit";
          $headers = 'From: noreply@example.com';
          $success = mail($userData['email_address'], $subject, $message, $headers);
          if (!$success) { 
              echo "Failed to send email to user"; echo "<br/>";  
          } else {
             $alert->insertSentAlert($value['user_id'], $value['user_alert_id']);
          }		
   			}
 			}
 		}
  }
    

 ?>