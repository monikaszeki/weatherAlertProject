<?php phpinfo(); ?>

<?php require_once  $_SERVER['DOCUMENT_ROOT'].'/config/config.php'; ?>

 
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  

    <title>Hello, world weather!</title>
  </head>
  <body>
  	<div class="container">
	    <div class="row">
	      <h2>Weather warnings on the go!</h2>
	    </div>
	    <div class="row-fluid">
		    <form  action='submitData.php' method="POST" id="select_form">
			  <div class="form-group">
			    <label for="email">Email address</label>
			    <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" required>
			  </div>
			  <div class="form-group">
			    <label for="cities">Select city</label>
			    <select name="cities" id="cities" class="form-control selectpicker" data-live-search="true">
				    <?php include $_SERVER['DOCUMENT_ROOT'].'/src/getCities.php'; ?>
				    <?php if ($result->num_rows > 0): ?>
	                	<?php while($array=mysqli_fetch_row($result)): ?>
		                 	<option value=<?php echo $array[0];?>><?php echo $array[1];?></option>
		                <?php endwhile; ?>
		                 <?php mysqli_free_result($result); ?>
	                <?php endif; ?>
			    </select>
			  </div>
			   <div class="form-group">
			    <label for="mintemp">Select temperature min</label>
			    <select name="mintemp" id="mintemp" class="form-control">
			       	<?php foreach (range(-20, 40) as $number) { ?> 
					    <option  <?php if($number==0){ echo "selected=".$number;};?>value=<?php echo $number;?>><?php echo $number;?></option>
					<?php } ?> 	 
			    </select>
			  </div>
			  <div class="form-group">
			    <label for="maxtemp">Select temperature max</label>
			    <select name="maxtemp" id="maxtemp" class="form-control">
			      <?php foreach (range(-20, 40) as $number) { ?> 
					    <option  <?php if($number==0){ echo "selected=".$number;};?>value=<?php echo $number;?>><?php echo $number;?></option>
					<?php } ?> 	 
			    </select>
			  </div>
			  <input type=hidden name="userID" id="userID" value="1"> 
			  <button type="submit" id="sumbit" name="submit" class="btn btn-primary">Submit</button>
			</form>
		</div>
	</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.0/js/bootstrap-select.min.js" integrity="sha512-4Z3wjB72KKDCH9Mrlkv36NmN1YsJiIH29OZ2Xy60/VRPZowGs0Mm3hBkrsuaaXPdvEywp4mVE/eOlMvvKLGZgA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  </body>
</html>
<script>


 






    