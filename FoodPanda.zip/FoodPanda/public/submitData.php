<?php
    require  $_SERVER['DOCUMENT_ROOT'].'/config/config.php'; 
    //======================================================================
    // Check if the user alreday signed up, if not sign up now.
    //======================================================================
     
     $user = new usersClass();
     
     if($row=$user->checkEmail($_POST['email'])) {
        $user->setId($row[0]);
        $go = false;
        $allAlerts = $user->getUserAlerts();    
        if($allAlerts) {
            foreach ($allAlerts as $key => $value) {
                if($_POST['cities']==$value['city_id']){
                    echo "You already signed up for this city alert!";
                    $go = true;
                }    
            }
            if(!$go) {
                $user->signUpAlert($_POST['cities'],$_POST['mintemp'],$_POST['maxtemp']);
                echo "Successfully sign up message alert!";
            }
        } else {
            $user->signUpAlert($_POST['cities'],$_POST['mintemp'],$_POST['maxtemp']);
            echo "Successfully sign up message alert!";
        }
       
    } else {
        if($user->insertUser($_POST['email'])) {
            $user->signUpAlert($_POST['cities'],$_POST['mintemp'],$_POST['maxtemp']);
            echo "Successfully sign up message alert!";
        }
    }
   
?>