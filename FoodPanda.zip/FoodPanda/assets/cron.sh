
*/10 * * * * /usr/bin/php /home/profiweb/foodpanda.profiweboldalkeszito.hu/public/cron.php
