<?php
	

	class mailClass {

		private $subject = "Weather alert";
		private $message = "The temperature is reached your limit";
		

		public function senMail($to) 
		{
			$headers = 'From: webmaster@example.com' . "\r\n" .
		    'Reply-To: webmaster@example.com' . "\r\n" .
		    'X-Mailer: PHP/' . phpversion();
			$success = mail($to, $ubject, $message, $headers);
			if (!$success) {
			    $errorMessage = error_get_last()['message'];
			} else {
				return true;
			}
		}
	}

