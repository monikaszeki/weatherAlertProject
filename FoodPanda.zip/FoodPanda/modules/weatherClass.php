<?php


class weatherClass {

	private $apiKey = "049766c799059a3a6e3b18f72c2c08c5";
    private $cityId = "";
    private $ch;

    public function __construct(){
    	$this->ch = curl_init();
		curl_setopt($this->ch, CURLOPT_HEADER, 0);
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($this->ch, CURLOPT_VERBOSE, 0);
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, false);

    }
    public function connectApi()
    { 
    	curl_setopt($this->ch, CURLOPT_URL, "http://api.openweathermap.org/data/2.5/weather?id=".$this->cityId ."&lang=en&units=metric&APPID=".$this->apiKey);
		
		$response = curl_exec($this->ch);
		if($response) {
		   $data = json_decode($response);
		   return $data;
		} else {
			echo "Weather connection failed";
		}
		

    }
    public function setCityId($id)
    {
    	$this->cityId = $id;
    }

    public function close()
    {
    	if($this->ch){
    		curl_close($this->ch);
    	}	
    }
    public function getCities()
    {
        $sql     = "SELECT * FROM cities";
        $result  = $this->conn->query($sql);
        if($result->num_rows == 0){
            echo "No result";
        } else {
            $cities = $result->fetch_assoc();
            // Free result set
            $result->close();
            //$this->conn->next_result();
            return $cities;  
        } 
            
    }

  

}

?>