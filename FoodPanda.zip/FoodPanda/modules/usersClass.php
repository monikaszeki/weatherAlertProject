<?php

	require_once  $_SERVER['DOCUMENT_ROOT'].'/config/config.php'; 

	class usersClass {

		private $conn;
		private $id;

	    public function __construct() {
	    	$this->conn = new databaseClass();
	    	$this->conn = $this->conn->getDb();
	    	
	    }

	    public function setId($id)
	    {
	    	$this->id = $id;
	    }

		public function getUserById($id)
		{
			$sql = "SELECT * FROM users WHERE id='$id'";
			$result  = $this->conn->query($sql);

	        if($result->num_rows == 0){
	            echo "No result";
	        } else {
	            $user =  $result->fetch_assoc();
	            $result->close();
	            return $user;  
	        } 
		}
		//======================================================================
		// insert new alert to database
		//======================================================================
		public function signUpAlert($city_id, $temp_min, $temp_max) 
		{
			$sql = "INSERT INTO user_alert (user_id, city_id, temp_min, temp_max) VALUES ('$this->id', '$city_id', '$temp_min', '$temp_max')";
			if ($result = $this->conn->query($sql) === TRUE) {
	          return true;
	        } else {
	          echo "Error: " . $sql . "<br>" . $conn->error;
	        }
		}

		//======================================================================
		// returns all alerts for a specific user
		//======================================================================
		public function getUserAlerts()
		{   
			$sql = "SELECT * FROM user_alert WHERE user_id='$this->id'";
			//$result = $this->conn->query($sql);
			if ($result = $this->conn->query($sql)) {
				while ($row = $result->fetch_assoc()) {
				   $alert_arr[]=$row;
				}
			}
			$result->close($alert_arr);
            return $alert_arr;  
		}
		//======================================================================
		// check if the email is already exists
		//======================================================================
		public function checkEmail($email)
		{
			/*Check is sent alerts today*/
	        $sql="SELECT * FROM users WHERE email_address='$email'" ;
	        $result = $this->conn->query($sql);
	       
	        if($result->num_rows == 0){
	            return false;
	        } else {
	            $row = $result->fetch_row();
	            // Free result set
	            $result->close();
	            //$this->conn->next_result();
	            return $row;  
	        }   	
		}

		public function insertUser($email)
		{
			$sql = "INSERT INTO users (email_address) VALUES ('$email')";
			if ($result = $this->conn->query($sql) === TRUE) {
				$last_id = $this->conn->insert_id;
				self::setId($last_id);
	          return true;
	        } else {
	          echo "Error: " . $sql . "<br>" . $conn->error;
	        }

		}
	}

?>
