<?php
	

	class alertClass {
		
		private $conn;
 
		public function __construct() 
		{
			$this->conn = new databaseClass();
			$this->conn = $this->conn->getDb();
			
		}
		//======================================================================
		// return all alerts from table
		//======================================================================
	    public function getAlerts()
	    {   	
			$sql     = "SELECT * FROM user_alert";
			$result  = $this->conn->query($sql);
	        if($result->num_rows == 0){
	            echo "No result";
	        } else {
	        	if ($result = $this->conn->query($sql)) {
					while ($row = $result->fetch_assoc()) {
					   $alert_arr[]=$row;
					}
				}
	            // Free result set
	            $result->close();
	            //$this->conn->next_result();
	            return $alert_arr;  
	        } 
			
	    }
	    //======================================================================
		// check if the alert has been sent for a specific user today
		//======================================================================
	    public function checkIsSend($user_alert_id)
	    {   $today = date('Y-m-d'); 
			/*Check is sent alerts today*/
	        $sql="SELECT * FROM sent_alerts WHERE user_alert_id='$user_alert_id' and date = '$today'" ;
	        $result = $this->conn->query($sql);
	       
	        if($result->num_rows == 0){
	            return false;
	        } else {
	            $row = $result->fetch_row();
	            // Free result set
	            $result->close();
	            //$this->conn->next_result();
	            return $row;  
	        }   	
	    }
	    //======================================================================
		// after an alert has been sent, register it 
		//======================================================================
	    public function insertSentAlert($user_id, $user_alert_id)
	    {
	    	$today = date('Y-m-d');
	    	$sql = "INSERT INTO sent_alerts (user_id, user_alert_id, date) VALUES ('$user_id', '$user_alert_id', '$today')";
	    	
	    	if ($result = $this->conn->query($sql) === TRUE) {
	          echo "New record created successfully";
	        } else {
	          echo "Error: " . $sql . "<br>" . $conn->error;
	        }
	    }

	}