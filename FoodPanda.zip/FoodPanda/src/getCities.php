<?php

	$conn   = new databaseClass();
	$conn   = $conn->getDb();
	$sql    = "SELECT * FROM cities LIMIT 100";
    $result  = $conn->query($sql);

?>