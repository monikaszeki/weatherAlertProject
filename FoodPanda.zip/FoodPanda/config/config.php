<?php


spl_autoload_register('autoloader');

function autoloader($classname) {
    include_once  $_SERVER['DOCUMENT_ROOT'].'/modules/'. $classname . '.php';
}
?>